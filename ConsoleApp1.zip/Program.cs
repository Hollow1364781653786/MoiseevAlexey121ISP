﻿using System.Globalization;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
var calendar = new GregorianCalendar();

Console.WriteLine("Введите год (четырехзначное число)");
int year = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите месяц (однозначное или двухзначное число/цифра)");
int month = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите день ((однозначное или двухзначное число/цифра)");
int day = Convert.ToInt32(Console.ReadLine());
var dateTime = new DateTime(year, month, day);
Console.WriteLine(dateTime.ToString());
DayOfWeek dayOfTheWeek = CultureInfo.CurrentCulture.Calendar.GetDayOfWeek(dateTime);
Console.WriteLine("день, который вы выбрали - " + dayOfTheWeek);