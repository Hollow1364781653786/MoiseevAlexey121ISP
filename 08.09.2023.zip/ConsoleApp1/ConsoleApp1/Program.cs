﻿// Разработайте генератор случайных чисел и проведите статистический анализ распределения случайных чисел
using System;
int[] randomArray = new int[10];
Random rnd = new Random();
int current = 0;
int highestCount = 1;
for (int i = 0; i < randomArray.Length; i++)
{
    randomArray[i] = rnd.Next(10);
    Console.Write(randomArray[i] + " ");
    current = randomArray[i];
    if (i > 0)
    {
        if (randomArray[i - 1] == current) highestCount++;
    }
}
Console.WriteLine(" ");
Console.WriteLine($"The highest sequence of matching numbers was {highestCount}");